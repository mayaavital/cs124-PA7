# Insert your TOGETHER_API_KEY and remove '.example' from the file name 
#added API key
TOGETHER_API_KEY= "3b9c27241c7cf86ac2fd4b8a72d1e51fb08d8cb528dc8efb399fcf4ff0fd3351"